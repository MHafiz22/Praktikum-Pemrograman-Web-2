<?php

namespace App\Models;

use CodeIgniter\Model;

class ProfilModel extends Model
{
    protected $nama = ": Muhammad Hafiz";
    protected $nim = ": 2110817210022";
    protected $prodi = ": Teknologi Informasi";
    protected $cita_cita = ": Pebisnis";
    protected $hobi = ": Main Game dan Olahraga";
    protected $skill = ": Desain UI/UX";
    protected $motto = ": Selalu Lakukan Yang Terbaik";
    protected $foto = "foto.jpeg";

    public function getNama()
    {
        return $this->nama;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getCita_cita()
    {
        return $this->cita_cita;
    }
    public function getHobi()
    {
        return $this->hobi;
    }
    public function getSkill()
    {
        return $this->skill;
    }
    public function getMotto()
    {
        return $this->motto;
    }
    public function getFoto1()
    {
        return $this->foto;
    }
}