<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        .custom-container {
            max-width: 850px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 12px 12px 2px 1px rgba(0, 0, 255, .2);
            border: 1px solid #000;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        img {
            max-width: 100%;
            height: 250px;
            border-radius: 10%;
            object-fit: cover;
            object-position: center;
            border: 1px solid #000;
        }

        th, td {
            padding: 5px;
        }

        button {
            margin-top: 10px;
            display: block;
            width: 50%;
            height: 40px;
            background-color: black;
            color: white;
            border: none;
            font-size: 15px;
            font-weight: bold;
        }
        
        button:hover {
            background-color: #b9e769;
            -webkit-box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
            -moz-box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
            box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
        }
    </style>
</head>
<body>
    <br><br><br>
    <div class="custom-container">
    <br>
    <h1 style = "margin-bottom: 20px;">Profil</h1>
        <div class="row g-8 p-10">
            <div class="col-md-8">
                <table>
                    <tr>
                        <th>Nama Lengkap </th>
                        <td>
                            <?= $nama; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>NIM </th>
                        <td>
                            <?= $nim; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Asal Prodi </th>
                        <td>
                            <?= $prodi; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Cita-cita </th>
                        <td>
                            <?= $citacita; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Hobi </th>
                        <td>
                            <?= $hobi; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Skill </th>
                        <td>
                            <?= $skill; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Motto Hidup </th>
                        <td>
                            <?= $motto; ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-sm-4">
                <img src="<?= base_url('images/'. $foto) ?>" alt="Gambar" class="profile-img" alt="...">
            </div>
            <form action="/home/index">
            <button>Beranda</button>
            </div>    
            <br>
        </div>
    </div>
</body>
</html>