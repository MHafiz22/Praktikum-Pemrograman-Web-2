<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda</title>
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        div {
            width: 400px;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 12px 12px 2px 1px rgba(0, 0, 255, .2);
            border: 1px solid #000;
        }

        h1 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 20px;
        }

        th, td {
            text-align: center;
            font-size: 20px;
            padding: 5px;
        }

        table {
            width: 100%;
        }

        button {
            margin-top: 10px;
            display: block;
            width: 100%;
            height: 40px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
        } 

        button:hover {
            background-color: #b9e769;
            -webkit-box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
            -moz-box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
            box-shadow: 10px 10px 99px 6px rgba(185, 231, 105, 1);
        }
    </style>
</head>
<body>
    <div>
    <table>
        <h1>Beranda</h1>
        <tr>
            <th>Nama Lengkap</th>
            <td>
                <?= $nama; ?>
            </td>
        </tr>
        <tr>
            <th>NIM</th>
            <td>
                <?= $nim; ?>
            </td>
        </tr>
    </table>
    <br>
    <form action="/home/Profil">
        <button>
            Profil
        </button>
    </form>
    </div>
</body>
</html>