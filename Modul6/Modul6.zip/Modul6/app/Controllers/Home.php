<?php

namespace App\Controllers;

use App\Models\ProfilModel;

class Home extends BaseController
{
    public function index()
    {
        $profil = new ProfilModel();
        return view('index',[
            "nama" => $profil->getNama(),
            "nim" => $profil->getNim(),
        ]);
    }

    public function Profil()
    {
        $profil = new ProfilModel();
        return view('Profil',[
            "nama" => $profil->getNama(),
            "nim" => $profil->getNim(),
            "prodi" => $profil->getProdi(),
            "citacita" => $profil->getCita_cita(),
            "hobi" => $profil->getHobi(),
            "skill" => $profil->getSkill(),
            "motto" => $profil->getMotto(),
            "foto" => $profil->getFoto1()
        ]); 
    }
}